# Making a mod

A mod is a **folder** inside `mods/` with a `mod.json` and the file(s) it uses. You never touch the hub's code.
Players switch mods on and off with the **🧩 button** in the hub. Mods show up for everyone as soon as they are in the repo.

## The folder

```
mods/
  my-cool-mod/
    mod.json      <- describes the mod
    theme.css     <- (or mod.js, or game.html: the file the mod uses)
```

## mod.json

```json
{
  "name": "My Cool Mod",
  "author": "your name",
  "description": "One short sentence about it.",
  "type": "theme",
  "entry": "theme.css"
}
```

| Field | Meaning |
| --- | --- |
| `name` | Shown in the 🧩 list |
| `author`, `description` | Optional, shown under the name |
| `type` | `theme`, `game` or `script` |
| `entry` | The file to use, in the same folder (or a full `https://` link) |
| `icon` | Optional picture for a game, in the same folder |

## The three types

**theme** (`entry` is a `.css` file). Changes how the hub looks. Colors live in variables, so this is usually all you need:
```css
html{--accent:#ff4fd8!important}
body{--bg:#12061f!important}
```

**game** (`entry` is an `.html` file or a link). Adds a game card to the hub. Turning the mod off removes it again. Games can't be larger than what GitHub allows (keep files under 25 MB).

**script** (`entry` is a `.js` file). Adds new features. Two helpers are ready to use:
```js
Mivyx.ready(() => { /* runs once the hub has started */ });
Mivyx.toast('Any message');
```
Script mods run code inside the hub, so players get a warning before turning one on.

## Share it
1. **Fork** this repository, add your folder under `mods/`, then press **Contribute → Open pull request**.
2. The **Check mods** test tells you right away if `mod.json` has a mistake.
3. The owner reads it and merges. After that it appears in everyone's 🧩 list, no hub update needed.

You can also host a mod yourself (for example on your own GitHub Pages). Players paste the link to your `mod.json` into the 🧩 panel under "Link to a mod.json".

## For the owner: before you merge
Themes and games are low risk. **Read every `.js` file in a script mod before merging**, because it can do anything the hub can (read saves, send data out). Under **Settings → Branches** you can require a review so nothing lands without you.
