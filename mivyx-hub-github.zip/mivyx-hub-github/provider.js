/* Account provider: where a player's profile is saved.
   By default the profile lives only on the player's own device (nothing is sent anywhere).
   To also sync it to a service (for example a company's login or chat system), replace the functions below.
   Nothing else in the hub needs to change.

   Rules a provider must follow:
   - it may only read or write the signed-in player's OWN profile
   - there is no admin / root path: nobody else can edit, disable or reset a player's profile or progress
   - real login, email verification, rate limits and permission checks must be enforced on the provider's SERVER,
     not in this file (a web page alone cannot enforce them) */
window.MivyxProvider = {
  name: 'this device',
  signIn:  async () => null,        // return { id, name } after a company login, else null
  load:    async () => null,        // return the saved profile object, or null
  save:    async (profile) => {},   // called a moment after any change (profile is null after "Delete all my data")
  signOut: async () => {}
};
