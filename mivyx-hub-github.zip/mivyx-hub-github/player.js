/* Mivyx Player: recently played, a player account that lives on the player's own device, and update choices.
   Loaded by the hub with <script src="player.js">. It sends nothing anywhere unless provider.js is changed. */
(()=>{
if(window.MvxPlayer)return;window.MvxPlayer=1;
document.querySelectorAll('[data-player]').forEach(e=>e.remove());
const KEY='mvxPlayer',MAXG=200,P=window.MivyxProvider||{};
const ls=k=>{try{return localStorage.getItem(k)||''}catch(e){return ''}},ss=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const tj=s=>{try{return JSON.parse(s)}catch(e){return null}};
const S=(x,n)=>String(x==null?'':x).slice(0,n),N=(x,m)=>Math.max(0,Math.min(m,+x||0));
const d8=t=>t?new Date(t).toLocaleDateString():'-';
const say=t=>{try{toast(t)}catch(e){}};

/* every profile (saved, synced or imported) passes through here: known fields only, hard size limits, never executed */
const clean=d=>{
 const o={v:1,name:'',created:0,updated:0,opts:{track:1,progress:1,showNew:1},games:Object.create(null),seen:null,fresh:[]};
 if(!d||typeof d!=='object')return o;
 o.name=S(d.name,40);o.created=N(d.created,4e12);o.updated=N(d.updated,4e12);
 for(const k in o.opts)o.opts[k]=d.opts&&d.opts[k]===0?0:1;
 if(Array.isArray(d.seen))o.seen=d.seen.slice(-300).map(x=>S(x,80));
 if(Array.isArray(d.fresh))o.fresh=d.fresh.slice(0,20).map(f=>({n:S(f&&f.n,80),t:N(f&&f.t,4e12)}));
 const gs=d.games&&typeof d.games==='object'?Object.entries(d.games).slice(0,MAXG):[];
 for(const[n,g]of gs){if(!g||typeof g!=='object')continue;const p=Object.create(null);
  if(g.prog&&typeof g.prog==='object')for(const[k,v]of Object.entries(g.prog).slice(0,20)){
   if(typeof v==='number'||typeof v==='boolean')p[S(k,30)]=v;else if(typeof v==='string')p[S(k,30)]=S(v,80)}
  o.games[S(n,80)]={first:N(g.first,4e12),last:N(g.last,4e12),n:N(g.n,1e6),min:N(g.min,1e6),prog:p}}
 return o};

let D=clean(tj(ls(KEY))),tmr;
const save=()=>{D.updated=Date.now();clearTimeout(tmr);tmr=setTimeout(()=>{
 const k=Object.keys(D.games);if(k.length>MAXG)k.sort((a,b)=>D.games[a].last-D.games[b].last).slice(0,k.length-MAXG).forEach(x=>delete D.games[x]);
 ss(KEY,JSON.stringify(D));if(P.save)Promise.resolve(P.save(D)).catch(()=>{})},800)};
if(P.load)Promise.resolve(P.load()).then(r=>{if(r){const c=clean(r);if(c.updated>D.updated){D=c;ss(KEY,JSON.stringify(D))}}}).catch(()=>{});

/* ---- tracking: wraps the hub's own launch / close ---- */
let cur=null;
const rec=n=>{if(!D.opts.track||!n)return;const g=D.games[n]||(D.games[n]={first:Date.now(),last:0,n:0,min:0,prog:Object.create(null)});g.n++;g.last=Date.now();cur={name:n,t:Date.now()};save()};
const end=()=>{if(!cur)return;const g=D.games[cur.name];if(g)g.min=Math.min(1e6,g.min+Math.round((Date.now()-cur.t)/6e4));cur=null;save()};
const wl=window.launch;if(typeof wl==='function')window.launch=async function(a){const r=await wl.apply(this,arguments);try{if(a&&gameOpen())rec(a.name)}catch(e){}return r};
const wc=window.closeApp;if(typeof wc==='function')window.closeApp=function(){end();return wc.apply(this,arguments)};
addEventListener('pagehide',end);
/* games can report progress:  parent.postMessage({mivyx:'progress',data:{level:3,score:1200}},'*') */
addEventListener('message',e=>{try{const f=document.getElementById('cloud-iframe'),m=e.data;
 if(!D.opts.progress||!cur||!f||e.source!==f.contentWindow||!m||m.mivyx!=='progress'||typeof m.data!=='object')return;
 const c=clean({games:{[cur.name]:{prog:m.data}}}).games[cur.name];if(c&&D.games[cur.name]){D.games[cur.name].prog=c.prog;save()}}catch(x){}});

/* ---- what is new in the library since the last visit ---- */
(window.Mivyx&&Mivyx.ready?Mivyx.ready:f=>setTimeout(f,4000))(()=>{try{
 const names=catalog.map(a=>a.name);
 if(!D.seen)D.seen=names;
 else{const add=names.filter(n=>!D.seen.includes(n));
  if(add.length){if(D.opts.showNew)D.fresh=[...add.map(n=>({n,t:Date.now()})),...D.fresh].slice(0,20);D.seen=[...D.seen,...add].slice(-300)}}
 save();
 if(!D.created&&!ls('mvpWelcomed')){ss('mvpWelcomed','1');open('m')}
}catch(e){}});

/* ---- the 👤 panel ---- */
const h=(t,p,...c)=>{const e=document.createElement(t);Object.assign(e,p||{});e.append(...c.flat().filter(x=>x!=null));return e};
const ui=h('div');ui.dataset.player='ui';
ui.innerHTML=`<style>
#mvp-b{position:fixed;right:64px;bottom:14px;z-index:20;width:42px;height:42px;border-radius:50%;border:1px solid rgba(255,255,255,.14);background:#12142a;color:#fff;font-size:19px;cursor:pointer;opacity:.75}
#mvp-b:hover,#mvp-b:focus-visible{opacity:1}
#mvp-p{position:fixed;inset:0;z-index:30;background:rgba(0,0,0,.62);display:none;align-items:center;justify-content:center;padding:16px}
#mvp-p.show{display:flex}
#mvp-p .w{width:min(520px,100%);max-height:86vh;overflow:auto;background:#0e1020;color:#f0f2fa;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:18px;font:14px/1.45 -apple-system,"Segoe UI",Roboto,sans-serif}
#mvp-p .h,#mvp-p .a,#mvp-p .m,#mvp-p .t{display:flex;gap:8px;align-items:center;justify-content:space-between}
#mvp-p .h{font-size:18px;margin-bottom:10px}#mvp-p .t{justify-content:flex-start;margin-bottom:8px}
#mvp-p .m{padding:9px 0;border-top:1px solid rgba(255,255,255,.07)}#mvp-p .m div{flex:1;min-width:0}
#mvp-p .m small{display:block;color:#8389a3}#mvp-p h4{margin:14px 0 4px;font-size:13px;color:#8389a3;font-weight:600}
#mvp-p input[type=checkbox],#mvp-p input[type=radio]{width:19px;height:19px;accent-color:var(--accent,#9aa5ff)}
#mvp-p input[type=text]{flex:1;min-width:0;padding:9px 10px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:rgba(0,0,0,.3);color:#fff;user-select:text}
#mvp-p button{padding:8px 12px;border-radius:9px;border:1px solid var(--accent,#9aa5ff);background:#1e224b;color:var(--accent,#9aa5ff);font:600 13px inherit;font-family:inherit;cursor:pointer}
#mvp-p button.on{background:var(--accent,#9aa5ff);color:#0a0b16}#mvp-p button.bad{border-color:#ff7597;color:#ff7597;background:transparent}
#mvp-p .a{margin-top:12px;flex-wrap:wrap;justify-content:flex-start}#mvp-p .n{margin:10px 0 0;color:#8389a3;font-size:12px}</style>
<button id="mvp-b" title="My Player" aria-label="My Player">👤</button>
<div id="mvp-p"><div class="w" role="dialog" aria-label="My Player"><div class="h"><b>👤 My Player</b><button id="mvp-x" aria-label="Close">✕</button></div><div class="t" id="mvp-t"></div><div id="mvp-c"></div></div></div>`;
document.body.appendChild(ui);
const q=s=>ui.querySelector(s),btn=(t,f,c)=>h('button',{onclick:f,className:c||''},t);
let tab='r';
function open(t){if(t)tab=t;q('#mvp-p').classList.add('show');render()}
const shut=()=>q('#mvp-p').classList.remove('show');
function render(){
 const t=q('#mvp-t'),c=q('#mvp-c');t.textContent='';c.textContent='';
 [['r','Recent'],['m','Me'],['u','Updates']].forEach(([k,l])=>t.append(btn(l,()=>{tab=k;render()},tab===k?'on':'')));
 ({r:recent,m:me,u:upd})[tab](c)}
const play=n=>{try{const a=catalog.find(x=>x.name===n);if(a){shut();launch(a)}else say('That game is not in your library any more')}catch(e){}};
const prog=g=>{const e=Object.entries(g.prog);return e.length?' · '+e.map(([k,v])=>k+': '+v).join(', '):''};

function recent(c){
 if(!D.opts.track)c.append(h('p',{className:'n'},'Remembering what you play is turned off (Me tab).'));
 const rows=Object.entries(D.games).filter(([,g])=>g.last).sort((a,b)=>b[1].last-a[1].last).slice(0,12);
 c.append(h('h4',{},'Recently played'));
 if(!rows.length)c.append(h('p',{className:'n'},'Games you play will show up here.'));
 for(const[n,g]of rows)c.append(h('div',{className:'m'},h('div',{},h('b',{},n),h('small',{},g.n+'× · '+g.min+' min · last '+d8(g.last)+prog(g))),btn('Play',()=>play(n)),btn('✕',()=>{delete D.games[n];save();render()})));
 const fr=D.fresh.filter(f=>{try{return catalog.some(a=>a.name===f.n)}catch(e){return false}});
 if(D.opts.showNew&&fr.length){c.append(h('h4',{},'New in your library'));
  for(const f of fr.slice(0,8))c.append(h('div',{className:'m'},h('div',{},h('b',{},f.n),h('small',{},'added '+d8(f.t))),btn('Play',()=>play(f.n))))}}

function me(c){
 if(!D.created){const i=h('input',{type:'text',placeholder:'Pick a player name',maxLength:40});
  c.append(h('p',{},'Create your player to keep your recent games and progress. It is saved on this device and only you control it.'),
   h('div',{className:'a'},i,btn('Create',()=>{const n=i.value.trim();if(!n)return;D.name=S(n,40);D.created=Date.now();save();render()})))}
 else{const T=Object.values(D.games).reduce((a,g)=>[a[0]+g.n,a[1]+g.min],[0,0]);
  c.append(h('p',{},h('b',{},D.name),' · since '+d8(D.created)),h('p',{className:'n'},T[0]+' plays · '+T[1]+' min total'))}
 c.append(h('h4',{},'What I keep'));
 [['track','Remember the games I play'],['progress','Remember my progress (in games that report it)'],['showNew','Show new games that arrive']].forEach(([k,l])=>
  c.append(h('label',{className:'m'},h('div',{},l),h('input',{type:'checkbox',checked:!!D.opts[k],onchange:e=>{D.opts[k]=e.target.checked?1:0;save()}}))));
 const f=h('input',{type:'file',accept:'.json,application/json',hidden:true,onchange:e=>{const x=e.target.files[0];e.target.value='';if(!x)return;
  if(x.size>2e5)return say('That file is too big to be a Mivyx account');
  x.text().then(s=>{const n=clean(tj(s));if(!n.created&&!n.name)return say('That is not a Mivyx account file');
   if(confirm('Replace the profile on this device with "'+n.name+'"?')){D=n;save();render();say('Account imported')}})}});
 const exp=()=>{const a=h('a',{href:URL.createObjectURL(new Blob([JSON.stringify(D,null,1)],{type:'application/json'})),download:'mivyx-account-'+(D.name||'player').replace(/[^\w-]+/g,'_')+'.json'});
  document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4e3)};
 const cp=()=>navigator.clipboard.writeText(JSON.stringify(D)).then(()=>say('Account copied'),()=>say('Copy not allowed here, use Export'));
 c.append(h('h4',{},'My account file'),h('div',{className:'a'},btn('Export',exp),btn('Copy',cp),btn('Import',()=>f.click()),f,
  btn('Delete all my data',()=>{if(!confirm('Delete your player, history and progress from this device?'))return;
   D=clean(null);try{localStorage.removeItem(KEY)}catch(e){}if(P.save)Promise.resolve(P.save(null)).catch(()=>{});render()},'bad')),
  h('p',{className:'n'},'Saved on: '+(P.name||'this device')+'. Only you can change your profile. You can import your own account file here, but not games.'))}

function upd(c){
 const cur=ls('mvxUpdPolicy')||'ask';
 c.append(h('h4',{},'When the hub has an update'));
 [['ask','Ask me first (recommended)'],['auto','Update automatically'],['never','Keep my current version']].forEach(([v,l])=>
  c.append(h('label',{className:'m'},h('div',{},l),h('input',{type:'radio',name:'pol',checked:cur===v,onchange:()=>{ss('mvxUpdPolicy',v);ss('mvxSkip','')}}))));
 c.append(h('p',{className:'n'},'This applies to the hub on this device. Mods are chosen one by one in 🧩. Games that arrive in an update come with the new hub version, so to avoid them pick "Keep my current version". Songs and mods still load from GitHub.'))}

q('#mvp-b').onclick=()=>open();q('#mvp-x').onclick=shut;q('#mvp-p').onclick=e=>{if(e.target.id==='mvp-p')shut()};
addEventListener('keydown',e=>{if(e.key==='Escape')shut()});
})();
