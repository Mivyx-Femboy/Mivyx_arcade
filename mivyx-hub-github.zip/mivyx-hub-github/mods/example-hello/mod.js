/* Mivyx.ready runs once the hub has started. Mivyx.toast shows a message. */
Mivyx.ready(() => Mivyx.toast('Hello from a mod! 👋'));
