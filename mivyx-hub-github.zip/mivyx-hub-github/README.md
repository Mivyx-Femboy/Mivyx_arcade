<p align="center">
  <img src="assets/banner.svg" alt="Mivyx Gaming Hub" width="100%">
</p>

<p align="center">
  <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest"><img alt="Latest release" src="https://img.shields.io/github/v/release/Mivyx-Femboy/Mivyx_arcade?style=for-the-badge&logo=github&labelColor=0d1117&color=8957e5"></a>
  <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases"><img alt="Downloads" src="https://img.shields.io/github/downloads/Mivyx-Femboy/Mivyx_arcade/total?style=for-the-badge&logo=github&labelColor=0d1117&color=1f6feb"></a>
  <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/actions/workflows/build-apps.yml"><img alt="Build" src="https://img.shields.io/github/actions/workflow/status/Mivyx-Femboy/Mivyx_arcade/build-apps.yml?style=for-the-badge&logo=githubactions&logoColor=white&labelColor=0d1117&label=BUILD"></a>
</p>

<h3 align="center"><code>&gt; Hey There!, welcome to the <a href="https://Mivyx-Femboy.github.io/Mivyx_arcade/">Mivyx Gaming Hub</a></code></h3>

<p align="center"><code>[ <a href="https://Mivyx-Femboy.github.io/Mivyx_arcade/">Play in your browser</a> ]</code></p>
<p align="center"><code>[ one hub for Android, Windows, Linux, iPhone and the web, and it updates itself ]</code></p>

<p align="center">
  <img alt="Android" src="https://img.shields.io/badge/ANDROID-3DDC84?style=for-the-badge&logo=android&logoColor=3DDC84&labelColor=0d1117">
  <img alt="Windows" src="https://img.shields.io/badge/WINDOWS-0078D4?style=for-the-badge&logo=windows11&logoColor=0078D4&labelColor=0d1117">
  <img alt="Linux" src="https://img.shields.io/badge/LINUX-FCC624?style=for-the-badge&logo=linux&logoColor=FCC624&labelColor=0d1117">
  <img alt="iOS" src="https://img.shields.io/badge/IOS-A2AAAD?style=for-the-badge&logo=apple&logoColor=A2AAAD&labelColor=0d1117">
  <img alt="PWA" src="https://img.shields.io/badge/PWA-5A0FC8?style=for-the-badge&logo=pwa&logoColor=A78BFA&labelColor=0d1117">
  <br>
  <img alt="HTML5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=E34F26&labelColor=0d1117">
  <img alt="JavaScript" src="https://img.shields.io/badge/JAVASCRIPT-F7DF1E?style=for-the-badge&logo=javascript&logoColor=F7DF1E&labelColor=0d1117">
  <img alt="Electron" src="https://img.shields.io/badge/ELECTRON-47848F?style=for-the-badge&logo=electron&logoColor=9FEAF9&labelColor=0d1117">
  <img alt="Capacitor" src="https://img.shields.io/badge/CAPACITOR-119EFF?style=for-the-badge&logo=capacitor&logoColor=119EFF&labelColor=0d1117">
  <img alt="GitHub Pages" src="https://img.shields.io/badge/GITHUB%20PAGES-8957E5?style=for-the-badge&logo=githubpages&logoColor=C297FF&labelColor=0d1117">
</p>

<details open>
<summary><h2>☰ About</h2></summary>

Mivyx is a game launcher with a built-in jukebox. Add your games, pick your music, and play on whatever you have in your hand.

- **Same hub everywhere.** Phone, tablet, PC, Linux box, browser.
- **Updates itself.** Every app opens the newest hub straight from this repository, so a new game or song shows up without a new download.
- **Works offline.** No connection? It opens the last copy it saved.
- **Mobile and Desktop layouts.** The hub picks one for you and shows its version number at start.

</details>

## 📘 Download the Hub -

<p align="center">
  <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest/download/Mivyx-Hub.apk"><img src="assets/card-android.svg" width="48%" alt="Android APK"></a>
  <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest/download/Mivyx-Hub-Setup.exe"><img src="assets/card-windows.svg" width="48%" alt="Windows EXE"></a>
</p>
<p align="center">
  <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest/download/Mivyx-Hub.AppImage"><img src="assets/card-linux.svg" width="48%" alt="Linux AppImage"></a>
  <a href="https://Mivyx-Femboy.github.io/Mivyx_arcade/"><img src="assets/card-ios.svg" width="48%" alt="iPhone and iPad"></a>
</p>
<p align="center">
  <a href="https://Mivyx-Femboy.github.io/Mivyx_arcade/"><img src="assets/card-web.svg" width="48%" alt="Play in the browser"></a>
  <a href="https://Mivyx-Femboy.github.io/Mivyx_arcade/mivyx-live.html"><img src="assets/card-live.svg" width="48%" alt="Live loader"></a>
</p>

<p align="center"><sub>Other files: <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest/download/Mivyx-Hub-Portable.exe">Windows portable</a> · <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest/download/Mivyx-Hub.deb">Linux .deb</a> · <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases/latest/download/Mivyx-Hub-unsigned.ipa">iOS .ipa (for AltStore / Sideloadly)</a> · <a href="https://github.com/Mivyx-Femboy/Mivyx_arcade/releases">all releases</a></sub></p>

<details>
<summary><b>How to install</b> (tap your device)</summary>

<br>

**Android.** Download `Mivyx-Hub.apk`, open it, and allow **Install unknown apps** for your browser when Android asks. If the install says "App not installed", uninstall any older Mivyx copy first.

**Windows.** Run `Mivyx-Hub-Setup.exe`. If SmartScreen warns you, click **More info**, then **Run anyway** (the app isn't code-signed). Prefer no install? Use the Portable file.

**Linux.** `chmod +x Mivyx-Hub.AppImage && ./Mivyx-Hub.AppImage`. On Ubuntu or Debian you can install the `.deb` instead: `sudo apt install ./Mivyx-Hub.deb`.

**iPhone / iPad (easiest).** Open the live hub in **Safari**, tap **Share**, then **Add to Home Screen**. It runs full-screen like an app and updates itself.
If you want the real app file, use the `.ipa` with [AltStore](https://altstore.io) or [Sideloadly](https://sideloadly.io). It is unsigned, so a free Apple ID keeps it alive for 7 days at a time.

**Any browser.** Open the live hub link. Chrome and Edge also offer **Install app** in the address bar.

</details>

## 🔄 How it updates itself

```mermaid
flowchart LR
  A["You export the<br>Public hub"] --> B["update.sh or<br>upload to GitHub"]
  B --> C["GitHub Pages<br>index.html"]
  C --> D["Browser and<br>iPhone home-screen app"]
  C --> E["Live loader inside<br>APK, EXE and Linux"]
  B -- "add: release" --> F["GitHub Actions builds<br>APK, EXE, Linux, iOS"]
  F --> G["Releases page<br>(download links never change)"]
  G --> H["Desktop app swaps<br>itself in the background"]
```

| Where you play | What updates | When |
| --- | --- | --- |
| Browser / iPhone home-screen app | Everything | Next time you open it |
| Windows and Linux app | The hub inside, **and** the app itself | Hub: every start. App: downloaded in the background |
| Android app | The hub inside | Every start. When a new APK exists the app shows a banner with a download button |
| `mivyx-live.html` | Everything | Every time you open the file |

## 🎵 Base music: what you need to do

The base songs are the playlist that plays for **everyone, on every version** (admin, public, guest, mobile). You manage it with one file, `base-songs.json`. No re-export needed. Changes show up the next time the hub opens.

**1. Pick how each song gets in**

| You have | You add |
| --- | --- |
| An MP3 file | `{ "name": "My song", "url": "music/my-song.mp3" }` |
| A YouTube link | `{ "name": "Chill mix", "url": "https://www.youtube.com/watch?v=VIDEOID" }` |

**2. MP3 only: upload the file**
Open the repo, go into the **music** folder, then **Add file → Upload files**, drag the mp3 in and **Commit changes**.
Use simple names like `my-song.mp3` (no spaces). The web uploader accepts files up to 25 MB each.

**3. Add the song to the list**
Open `base-songs.json`, click the **✏️ pencil**, then write your list and **Commit changes**:

```json
[
  { "name": "My song", "url": "music/my-song.mp3" },
  { "name": "Chill mix", "url": "https://www.youtube.com/watch?v=VIDEOID" }
]
```

**4. Check it worked**
Open the **Actions** tab. **Check music list** shows a green ✓ when every song is found, or a red ✗ that names the song with the problem. Then reload the hub. Your songs are in the music panel. In an app, close it and open it again.

<details>
<summary><b>If a song doesn't show up</b></summary>

<br>

- The list must start with `[` and end with `]`, with a comma after every song **except the last**.
- Use straight quotes `"like this"`, not curly ones.
- The file name in `url` must match the uploaded file exactly, including capitals: `music/My-Song.mp3` is not `music/my-song.mp3`.
- YouTube songs play when the hub is on a web address (the live site, the apps, the home-screen app). They won't play from an HTML file saved on your computer. If one won't play inside an app, use an MP3 instead.
- Only upload music you have the right to share. A public repository is public.

</details>

## 🧩 Mods: add anything without touching code

Mods are small folders anyone can make. Players switch them on from the **🧩 button** in the hub.

| Mod type | What it does | Files you need |
| --- | --- | --- |
| **theme** | Changes the colors and look | `mod.json` + a `.css` file |
| **game** | Adds a game card to the hub | `mod.json` + an `.html` file (or a link) |
| **script** | Adds new features (runs code) | `mod.json` + a `.js` file |

**Make one.** Add a folder like `mods/my-mod/` with a `mod.json` and your file. Three small examples are already in [`mods/`](mods/). Full guide: **[docs/MODS.md](docs/MODS.md)**.

**Share one.** Fork the repo, add your folder, then **Contribute → Open pull request**. Once it's merged it shows up for everyone, no hub update needed.

**Use one from anywhere.** In the hub open 🧩, paste a link to any `mod.json`, and tick it on.

> ⚠️ Script mods can do anything the hub can do. Only turn on mods from people you trust.

## 👤 Players: recent games, your own account, your choices

The **👤 button** in the hub opens **My Player**.

- **Recent:** the games you played lately (how many times, minutes, last played, and progress for games that report it) plus new games that arrived.
- **Me:** make a player name, choose what the hub remembers, **Export / Import** your own account file, or **Delete all my data**. It lives on your device. You can import your account, never games.
- **Updates:** *Ask me first*, *Update automatically*, or *Keep my current version*. Installed apps still reach GitHub for songs and mods either way.

**For companies:** `provider.js` is the one small file to change to save a player's profile in your own login or chat service. Nothing else in the hub needs editing, and a provider can only ever touch the signed-in player's own profile.

## 🛠 Update the hub

**Easiest (browser).** Export again from the hub with **📤 Export Single File (Public)**. Open the repo, click `index.html`, then **✏️ / Upload** and replace it with the new export (renamed `index.html`), then **Commit**. Live in about a minute.

**One command.**

```bash
bash update.sh "Exported Hub.html" "added new games"
```

**New app files too (APK, EXE, Linux, iOS).** Raise `HUB_VERSION` in the hub, export, then add `release`:

```bash
bash update.sh "Exported Hub.html" "version 2.1.0" release
```

The builds appear under **Releases** in about 15 minutes and the download buttons above keep working.

> ⚠️ **Never upload the admin file.** Only the **Public** export belongs on GitHub. The build refuses to run if `index.html` is the admin version, and `.gitignore` skips any file with `admin` in its name.

First time here? Follow **[docs/SETUP.md](docs/SETUP.md)** (about 10 minutes, no command line needed).

<p align="center"><sub><code>[ Mivyx Gaming Hub · built to update itself ]</code></sub></p>
