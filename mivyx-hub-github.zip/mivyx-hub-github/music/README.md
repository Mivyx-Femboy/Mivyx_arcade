# music/
Drop your .mp3 files in this folder, then add each one to `base-songs.json` (see the Music section in the main README).
Use simple file names: `my-song.mp3` (no spaces).
