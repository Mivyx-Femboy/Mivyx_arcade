/* Mivyx mod runtime. The hub loads this with <script src="mods.js">. You never edit it:
   mods are just folders inside /mods (see docs/MODS.md). Players switch them on with the 🧩 button. */
(()=>{
if(window.Mivyx)return;
document.querySelectorAll('[data-mod]').forEach(e=>e.remove()); /* clear anything an export copied in */
const ls=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const abs=(u,b)=>new URL(u,b||document.baseURI).href;
let on=ls('mvxModsOn',{}),mine=ls('mvxModsLink',[]);
const bu=new URL(document.baseURI),hm=bu.hostname.match(/^([^.]+)\.github\.io$/),p1=bu.pathname.split('/')[1];
const gh=hm?{o:hm[1],r:p1&&!/\.html?$/i.test(p1)?p1:hm[1]+'.github.io'}:null;

/* resolves when the hub has finished starting (mods that add games or run code wait for it) */
const ready=new Promise(ok=>{let n=0;const t=setInterval(()=>{let up=false;try{up=!!db&&typeof putApp==='function'}catch(e){}if(up||++n>150){clearInterval(t);setTimeout(ok,700)}},200)});
window.Mivyx={ready:f=>ready.then(f),toast:t=>{try{toast(t)}catch(e){}}};

const norm=(j,dir,id,link)=>{
 if(!j||typeof j.name!=='string'||!/^(theme|script|game)$/.test(j.type)||typeof j.entry!=='string')return null;
 const m={id,link:link?1:0,name:j.name.slice(0,60),author:String(j.author||'').slice(0,40),desc:String(j.description||'').slice(0,200),type:j.type,entry:abs(j.entry,dir),icon:j.icon?abs(j.icon,dir):''};
 return/^https?:/.test(m.entry)?m:null};

async function repoList(){
 const c=ls('mvxModList',null);if(!gh)return[];if(c&&Date.now()-c.t<6e5)return c.l;
 try{const d=await(await fetch(`https://api.github.com/repos/${gh.o}/${gh.r}/contents/mods`)).json();
  const l=(await Promise.all(d.filter(x=>x.type==='dir').map(async x=>{try{const dir=abs('mods/'+encodeURIComponent(x.name)+'/');return norm(await(await fetch(dir+'mod.json',{cache:'no-cache'})).json(),dir,x.name)}catch(e){return null}}))).filter(Boolean);
  sv('mvxModList',{t:Date.now(),l});return l}catch(e){return c?c.l:[]}}
async function addLink(u){
 const j=await(await fetch(u,{cache:'no-cache'})).json(),id='x'+[...u].reduce((h,c)=>(h*31+c.charCodeAt(0))>>>0,7).toString(36),m=norm(j,abs('./',u),id,1);
 if(!m)throw 0;if(!mine.some(x=>x.id===id))mine.push(m);sv('mvxModsLink',mine);return m}

/* games: added to / removed from the hub's own game list (only ever removes the exact game the mod added) */
const apps=()=>req(st('apps').getAll());
async function gameOn(m){if((await apps()).some(a=>a.name===m.name&&a.url===m.entry))return;
 await putApp({name:m.name,url:m.entry,img:m.icon,guest:1,pub:1});await loadCatalog()}
async function gameOff(m){const a=(await apps()).find(x=>x.name===m.name&&x.url===m.entry);if(!a)return;
 await new Promise(ok=>{const tx=db.transaction(['apps','app_files'],'readwrite');tx.objectStore('apps').delete(a.id);tx.objectStore('app_files').delete(a.id);tx.oncomplete=ok;tx.onerror=ok});await loadCatalog()}

const tag=(m,t,a)=>{const e=document.createElement(t);e.dataset.mod=m.id;Object.assign(e,a);document.head.appendChild(e)};
async function apply(m){if(m.type==='theme')tag(m,'link',{rel:'stylesheet',href:m.entry});else if(m.type==='script')tag(m,'script',{src:m.entry});else await gameOn(m)}
async function drop(m){[...document.querySelectorAll('[data-mod]')].filter(e=>e.dataset.mod===m.id).forEach(e=>e.remove());
 if(m.type==='game')await gameOff(m);else if(m.type==='script')Mivyx.toast('Reload the hub to fully turn this mod off')}

for(const id in on)if(on[id].type==='theme')apply(on[id]);               /* themes apply instantly */
ready.then(async()=>{for(const id in on)if(on[id].type!=='theme')await apply(on[id]).catch(()=>{})});

/* ---------- the 🧩 panel ---------- */
const ui=document.createElement('div');ui.dataset.mod='ui';
ui.innerHTML=`<style>
#mvx-mb{position:fixed;right:14px;bottom:14px;z-index:20;width:42px;height:42px;border-radius:50%;border:1px solid rgba(255,255,255,.14);background:#12142a;color:#fff;font-size:20px;cursor:pointer;opacity:.75}
#mvx-mb:hover,#mvx-mb:focus-visible{opacity:1}
#mvx-mp{position:fixed;inset:0;z-index:30;background:rgba(0,0,0,.62);display:none;align-items:center;justify-content:center;padding:16px}
#mvx-mp.show{display:flex}
#mvx-mp .w{width:min(520px,100%);max-height:86vh;overflow:auto;background:#0e1020;color:#f0f2fa;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:18px;font:14px/1.45 -apple-system,"Segoe UI",Roboto,sans-serif}
#mvx-mp .h,#mvx-mp .a,#mvx-mp .m{display:flex;gap:10px;align-items:center;justify-content:space-between}
#mvx-mp .h{margin-bottom:10px;font-size:18px}
#mvx-mp .m{padding:10px 0;border-top:1px solid rgba(255,255,255,.07);cursor:pointer}
#mvx-mp .m div{flex:1;min-width:0}#mvx-mp .m span{color:#8389a3;font-size:12px;margin-left:6px}#mvx-mp .m p{margin:2px 0 0;color:#a9aec6;font-size:13px}
#mvx-mp input[type=checkbox]{width:20px;height:20px;accent-color:var(--accent,#9aa5ff)}
#mvx-mp input[type=text]{flex:1;min-width:0;padding:9px 10px;border-radius:9px;border:1px solid rgba(255,255,255,.1);background:rgba(0,0,0,.3);color:#fff;user-select:text}
#mvx-mp button{padding:8px 13px;border-radius:9px;border:1px solid var(--accent,#9aa5ff);background:#1e224b;color:var(--accent,#9aa5ff);font:600 13px inherit;font-family:inherit;cursor:pointer}
#mvx-mp .a{margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.07)}
#mvx-mp .n{margin:12px 0 0;color:#8389a3;font-size:12px}</style>
<button id="mvx-mb" title="Mods" aria-label="Mods">🧩</button>
<div id="mvx-mp"><div class="w" role="dialog" aria-label="Mods"><div class="h"><b>🧩 Mods</b><button id="mvx-x" aria-label="Close">✕</button></div>
<div id="mvx-l"></div>
<div class="a"><input type="text" id="mvx-u" placeholder="Link to a mod.json"><button id="mvx-add">Add</button></div>
<p class="n">Mods run inside your hub. Only turn on mods from people you trust.</p></div></div>`;
document.body.appendChild(ui);
const q=s=>ui.querySelector(s),el=(t,x)=>{const e=document.createElement(t);if(x)e.textContent=x;return e};

async function show(){
 const box=q('#mvx-l');box.textContent='Loading…';const list=[...await repoList(),...mine];box.textContent='';
 if(!list.length)box.textContent='No mods yet. Add one with a link below.';
 for(const m of list){
  const r=el('label');r.className='m';const t=el('div'),b=el('b',m.name);t.append(b,el('span',m.type+(m.author?' · by '+m.author:'')),el('p',m.desc));
  const c=el('input');c.type='checkbox';c.checked=!!on[m.id];
  c.onchange=async()=>{
   if(c.checked&&m.type==='script'&&!confirm('"'+m.name+'" runs code inside your hub and can see your games and saves.\nOnly turn it on if you trust its author.')){c.checked=false;return}
   if(c.checked){on[m.id]=m;sv('mvxModsOn',on);await apply(m).catch(()=>Mivyx.toast('Could not load that mod'))}
   else{delete on[m.id];sv('mvxModsOn',on);await drop(m)}};
  r.append(t,c);
  if(m.link){const x=el('button','✕');x.title='Remove from list';x.onclick=async e=>{e.preventDefault();if(on[m.id]){delete on[m.id];sv('mvxModsOn',on);await drop(m)}mine=mine.filter(y=>y.id!==m.id);sv('mvxModsLink',mine);show()};r.append(x)}
  box.appendChild(r)}}
const open=()=>{q('#mvx-mp').classList.add('show');show()},shut=()=>q('#mvx-mp').classList.remove('show');
q('#mvx-mb').onclick=open;q('#mvx-x').onclick=shut;q('#mvx-mp').onclick=e=>{if(e.target.id==='mvx-mp')shut()};
addEventListener('keydown',e=>{if(e.key==='Escape')shut()});
q('#mvx-add').onclick=async()=>{const u=q('#mvx-u').value.trim();
 if(!/^https?:\/\//.test(u))return Mivyx.toast('Paste a link that starts with https://');
 if(!confirm('Add a mod from '+new URL(u).hostname+'?\nOnly add mods from people you trust.'))return;
 try{await addLink(u);q('#mvx-u').value='';show()}catch(e){Mivyx.toast('That link is not a valid mod.json')}};
})();
