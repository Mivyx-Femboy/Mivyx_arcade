#!/usr/bin/env python3
"""Checks every mods/<name>/mod.json so mistakes show up before a mod is merged."""
import json, os, sys
bad = 0
names = sorted(os.listdir("mods")) if os.path.isdir("mods") else []
for d in names:
    p = os.path.join("mods", d)
    if not os.path.isdir(p):
        continue
    try:
        j = json.load(open(os.path.join(p, "mod.json"), encoding="utf-8"))
    except Exception as e:
        print(f"X {d}: mod.json is missing or not valid JSON ({e})"); bad += 1; continue
    errs = []
    if not isinstance(j.get("name"), str) or not j["name"].strip():
        errs.append('needs a "name"')
    if j.get("type") not in ("theme", "script", "game"):
        errs.append('"type" must be "theme", "script" or "game"')
    for key in ("entry", "icon"):
        v = j.get(key)
        if key == "entry" and not (isinstance(v, str) and v):
            errs.append('needs an "entry" file')
        elif isinstance(v, str) and v and not v.startswith(("http://", "https://")) and not os.path.isfile(os.path.join(p, v)):
            errs.append(f'"{key}" file not found: {v} (same spelling and capitals?)')
    if errs:
        print(f"X {d}: " + "; ".join(errs)); bad += 1
    else:
        print(f"OK {d} ({j['type']})")
print(f"{bad} problem(s)")
sys.exit(1 if bad else 0)
